return LoadActor("StepsDisplayList cursor p1") .. {
	InitCommand=cmd(zoomx,-1;);
};