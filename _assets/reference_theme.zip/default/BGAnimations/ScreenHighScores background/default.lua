return LoadActor( "bg" ) .. {
	InitCommand = cmd(x,SCREEN_CENTER_X;y,SCREEN_CENTER_Y;)
}
