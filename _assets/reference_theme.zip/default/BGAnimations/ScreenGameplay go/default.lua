local t = LoadActor( "go" ) .. {
	OnCommand = cmd(x,SCREEN_CENTER_X;y,SCREEN_CENTER_Y;diffusealpha,0;linear,0.5;diffusealpha,1;sleep,0.5;linear,0.5;diffusealpha,0);
}
return t
