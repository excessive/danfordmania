return Def.ActorFrame {
	LoadActor( "bg" ) .. {
		OnCommand=cmd(x,SCREEN_CENTER_X;y,SCREEN_CENTER_Y);
	};
};
