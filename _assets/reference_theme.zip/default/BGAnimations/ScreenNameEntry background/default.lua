return LoadActor( "_name entry" ) .. {
	InitCommand = cmd(stretchto,SCREEN_LEFT,SCREEN_TOP,SCREEN_RIGHT,SCREEN_BOTTOM),
}
