return LoadActor( THEME:GetPathS("", "_prompt") ) .. {
	StartTransitioningCommand=cmd(play);
};
