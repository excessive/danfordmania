return LoadFont("common normal") .. {
	InitCommand=cmd(settext,"*";);
};