return Def.Quad {
	InitCommand=cmd(zoomtowidth,8;zoomtoheight,8;diffuse,color("#ffa944"));
};