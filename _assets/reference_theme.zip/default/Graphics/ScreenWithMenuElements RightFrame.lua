return LoadActor("ScreenWithMenuElements LeftFrame") .. {
	InitCommand=cmd(zoomx,-1;);
};