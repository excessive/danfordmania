return Def.Quad {
	InitCommand=cmd(zoomtowidth,232;zoomtoheight,24;diffuseshift;effectcolor1,color("1,0,0,0.8");effectcolor2,color("1,0,0,0");effectclock,"music";);
};
