return LoadActor("OptionsCursor CanGoLeft") .. {
	InitCommand=cmd(zoomx,-1;);
};