return Def.Quad {
	InitCommand=cmd(zoomtowidth,2;zoomtoheight,76;diffuse,color("#FFFFFF77"););
};