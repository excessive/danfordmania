return Def.ActorFrame {
	LoadFont( "common normal" ) .. {
		InitCommand=cmd(shadowlength,0;settext,ScreenString("HeaderText"););
	};
};
