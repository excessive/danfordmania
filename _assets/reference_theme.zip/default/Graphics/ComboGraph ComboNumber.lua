return LoadFont("Common Normal") .. {
	InitCommand=cmd(shadowlengthx,0;shadowlengthy,2;strokecolor,color("#00000077"););
};