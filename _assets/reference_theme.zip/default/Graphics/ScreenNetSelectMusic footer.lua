return LoadActor("_footer shared (doubleres)") ..
{
	InitCommand=cmd(draworder,-1);
}
