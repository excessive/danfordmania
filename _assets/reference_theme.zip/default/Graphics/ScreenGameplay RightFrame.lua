return LoadActor("ScreenGameplay LeftFrame") .. {
	InitCommand=cmd(zoomx,-1;);
};