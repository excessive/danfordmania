return Def.Quad {
	InitCommand=cmd(diffuse,{0.5,0.5,1,0.7};zoomtowidth,150;zoomtoheight,24);
};
