return Def.Quad {
	InitCommand=cmd(zoomtowidth,232;zoomtoheight,24;diffuse,color("0.2,0.2,0.2,1");diffusetopedge,color("0.5,0.5,0.5,1"););
};
