return LoadActor( THEME:GetPathG("ControllerStateDisplay","Center") ) .. {
	InitCommand=cmd(x,8;y,-8);
};